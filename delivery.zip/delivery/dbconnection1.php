<?php
$db = mysqli_connect("localhost","svasth","svasth@2017","svasth_enquiry");

 ?>
