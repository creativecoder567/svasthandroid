<?php
require 'dbconnection1.php';

$data=$_POST;

$ORDERID="";
$USERID="";
$DATEID="";
$BRECEIVED="";
$response=array();
$json = array();

if (array_key_exists('orderid', $data)){
    $ORDERID= $data['orderid'];
  }
  if (array_key_exists('userid', $data)){
      $USERID= $data['userid'];
    }
    if (array_key_exists('dateid', $data)){
        $DATEID= $data['dateid'];
      }
      if (array_key_exists('breceived', $data)) {
        $BRECEIVED=$data['breceived'];
      }
      //echo $BRECEIVED;

      date_default_timezone_set('Asia/Calcutta');
      $ctime=date('H:i:s');

      if( strtotime($ctime)<=strtotime('12:00:00') ){

        $sql="UPDATE  `svasth_enquiry`.`litre` SET  `delivery_status_m` =  'Y',`bottle_received_m`='$BRECEIVED' WHERE  `litre`.`id` = '$DATEID' AND `litre`.`userid` = '$USERID' AND `litre`.`orderid` = '$ORDERID'";
      }else {
                $sql="UPDATE  `svasth_enquiry`.`litre` SET  `delivery_status_e` =  'Y',`bottle_received_e`='$BRECEIVED' WHERE  `litre`.`id` = '$DATEID' AND `litre`.`userid` = '$USERID' AND `litre`.`orderid` = '$ORDERID'";
      }

      $result = mysqli_query($db, $sql);

      if ($result) {
          $json['success'] = 200;
         $json['message'] ="success";
          echo json_encode($json);
      } else {
          $json['success'] = 404;
          $json['message'] ="fail";
          echo json_encode($json);
      }
 ?>
