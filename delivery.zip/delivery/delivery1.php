<?php
require 'dbconnection1.php';

$DBOYID="";

$data=$_POST;
$response=array();
$response["litre:"]=array();
$json = array();

if (array_key_exists('dboyid', $data)){
    $DBOYID= $data['dboyid'];
  }

  // $sql="select * from delivery WHERE deliveryboy_id = '$DBOYID' ";
  // $result=mysqli_query($db,$sql);
  //
  //   while ($row = mysqli_fetch_array($result)) {
  //     array_push($response,array('userid'=>$row['user_id'],'name'=>$row['name'],'address'=>$row['address'],'phone'=>$row['phone']));
  //   }
//echo "Today is " . date("d-m-Y") . "<br>";
//$today=date("d-m-Y");
$today="01-01-2018";
//$sql="select date from litre WHERE date ='$date' AND  userid= (select user_id from order_history where location = 'Banshankari')";
$sql="select * from litre WHERE date ='$today' AND  userid  IN (select user_id from order_history where location = 'Banshankari')";

$result=mysqli_query($db,$sql);

// if ($result) {
//   echo "success";
// }else {
//   echo "fail";
// }

$final=array();
$final["user:"]=array();

/* $sql1="select * from user where id= 56";
$result1=mysqli_query($db,$sql1);

// if ($result1) {
//   echo "success";
// }else {
//   echo "fail";
// }
while($row1=mysqli_fetch_assoc($result1)){
   $user=array(
     "name"=>$row1['name'],
     "mobile"=>$row1['mobile']
   );
   array_push($final["user:"], $user);
}*/
//echo json_encode($final["user:"]);

/*while ($row = mysqli_fetch_array($result)) {
  // $orderid=$row['id'];
  // $userid=$row['userid'];
   array_push($response["litre:"],array('userid'=>$row['userid'],'orderid'=>$row['orderid'],'morning_litre'=>$row['morning_litre']));
     //array_push($response,array('date'=>$row['date']));
// echo $orderid;
// echo $userid;
   //array_push($final,array('litre:'=>$response));
}*/

 while ($row=mysqli_fetch_assoc($result)) {
//   $litre=array('userid'=>$row['userid'],'orderid'=>$row['orderid'],'morning_litre'=>$row['morning_litre']));
//   array_push($response["litre:"],$litre);

$id= $row['userid'];
   $sql1="select * from user where id= $id";
  $result1=mysqli_query($db,$sql1);
  while($row1=mysqli_fetch_assoc($result1)){
     $user=array(
       "name"=>$row1['name'],
       "mobile"=>$row1['mobile']
     );
    // array_push($final["user:"], $user);
  }
   $product_item=array(
           "userid" => $row['userid'],
           "orderid" => $row['orderid'],
           "morning_litre" => $row['morning_litre'],
           "user"=>$user
       );

       array_push($response["litre:"], $product_item);
 }
    $json = json_encode($response);
    echo $json;


 ?>
